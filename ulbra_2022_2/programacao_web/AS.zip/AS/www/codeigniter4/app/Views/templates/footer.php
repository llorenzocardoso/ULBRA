</section>
        </div>
    </div>

    <footer class="text-center text-white pt-4">

        <div class="text-center text-dark">
            <a class="text-dark" href="<?=base_url('admin')?>">Área Administrativa</a>
        </div>

        <div class="container p-1">
            <!-- Social media -->
            <section class="mb-4">
                <!-- Instagram -->
                <a
                    class="btn btn-link btn-floating btn-lg text-dark m-1" href="https://www.instagram.com/llorenzocardoso/" target="_blank" role="button" data-mdb-ripple-color="dark">
                    <i class="fab fa-instagram"></i>
                </a>

                <!-- Linkedin -->
                <a
                    class="btn btn-link btn-floating btn-lg text-dark m-1" href="https://www.linkedin.com/in/lorenzo-cardoso-462b61233/" target="_blank" role="button" data-mdb-ripple-color="dark">
                    <i class="fab fa-linkedin"></i>
                </a>
                
                <!-- Github -->
                <a
                    class="btn btn-link btn-floating btn-lg text-dark m-1" href="https://github.com/llorenzocardoso" target="_blank" role="button" data-mdb-ripple-color="dark">
                    <i class="fab fa-github"></i>
                </a>
            </section>
        </div>
    </footer>
    
</body>
</html>