</section>
</div>
</div>

    <footer class="text-center text-white p-4">
        <div class="text-center text-dark p-2">
            <a class="text-dark" href="../index.php">Site</a>
        </div>


    </footer>

</body>
</html>